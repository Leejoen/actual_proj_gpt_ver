function DashboardPage() {
  return <div style={{ padding: '2rem', fontSize: '1.5rem' }}>DashboardPage works!</div>;
}

export default DashboardPage;